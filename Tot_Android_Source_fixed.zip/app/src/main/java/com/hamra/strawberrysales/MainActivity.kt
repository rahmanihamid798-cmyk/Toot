package com.hamra.strawberrysales

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import android.graphics.Typeface
import android.graphics.Color
import android.text.InputType
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : Activity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val products = listOf("فوق", "سوپر", "ممتاز", "دفرمه", "فله")
    private val rows = mutableMapOf<String, ProductInputs>()
    private lateinit var root: LinearLayout
    private lateinit var statusText: TextView
    private var isOwner = false
    private var reviewDate = ""
    private var ownerPhone = ""

    data class ProductInputs(
        val cartons: EditText,
        val weight: EditText,
        val price: EditText,
        val total: TextView,
        val weightTotal: TextView
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blocks standard screenshots and most screen recording on Android.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        showLogin()
    }

    private fun showLogin() {
        root = page()
        addTitle("فروش روزانه توت‌فرنگی")
        addText("برای ورود، شماره تلفن را با کد کشور وارد کنید.")
        val phone = edit("شماره تلفن، مثل +98912...")
        val send = Button(this).apply { text = "ارسال کد تأیید" }
        val code = edit("کد پیامک‌شده")
        val verify = Button(this).apply { text = "تأیید و ورود" }
        var verificationId: String? = null

        send.setOnClickListener {
            val p = phone.text.toString().trim()
            if (!p.startsWith("+") || p.length < 9) {
                toast("شماره را با کد کشور وارد کنید؛ مثل +98912...")
                return@setOnClickListener
            }
            com.google.firebase.auth.PhoneAuthProvider.verifyPhoneNumber(
                com.google.firebase.auth.PhoneAuthOptions.newBuilder(auth)
                    .setPhoneNumber(p)
                    .setTimeout(60L, java.util.concurrent.TimeUnit.SECONDS)
                    .setActivity(this)
                    .setCallbacks(object : com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                            signIn(credential)
                        }
                        override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                            toast("ارسال/تأیید پیامک ناموفق بود: ${e.localizedMessage ?: "خطا"}")
                        }
                        override fun onCodeSent(id: String, token: com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken) {
                            verificationId = id
                            toast("کد ارسال شد.")
                        }
                    }).build()
            )
        }
        verify.setOnClickListener {
            val id = verificationId
            val sms = code.text.toString().trim()
            if (id.isNullOrBlank() || sms.isBlank()) {
                toast("ابتدا کد پیامک را دریافت و وارد کنید.")
            } else {
                signIn(com.google.firebase.auth.PhoneAuthProvider.getCredential(id, sms))
            }
        }
        root.addView(phone); root.addView(send); root.addView(code); root.addView(verify)
        setContentView(root)
    }

    private fun signIn(credential: com.google.firebase.auth.PhoneAuthCredential) {
        auth.signInWithCredential(credential).addOnSuccessListener {
            loadRoleAndShow()
        }.addOnFailureListener { toast("ورود انجام نشد: ${it.localizedMessage}") }
    }

    private fun loadRoleAndShow() {
        val user = auth.currentUser ?: return showLogin()
        db.collection("settings").document("app").get().addOnSuccessListener { settings ->
            ownerPhone = settings.getString("ownerPhone") ?: ""
            db.collection("users").document(user.uid).get().addOnSuccessListener { profile ->
                isOwner = profile.getString("role") == "owner" &&
                    user.phoneNumber == ownerPhone && ownerPhone.isNotBlank()
                showSales()
            }.addOnFailureListener { toast("دریافت مجوزها ناموفق بود.") }
        }.addOnFailureListener { toast("تنظیمات برنامه در سرور پیدا نشد.") }
    }

    private fun showSales() {
        root = page()
        addTitle("فروش روزانه توت‌فرنگی")
        val today = SimpleDateFormat("yyyy/MM/dd", Locale("fa", "IR")).format(Date())
        addText("تاریخ فروش: $today")
        statusText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.DKGRAY)
            text = if (reviewDate.isBlank()) "هنوز تاریخ بررسی حساب ثبت نشده است" else "حساب بررسی شده تا: $reviewDate"
            setPadding(0, 12, 0, 12)
        }
        root.addView(statusText)

        products.forEach { name ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 16, 20, 16)
                setBackgroundColor(Color.rgb(250, 245, 242))
            }
            val heading = TextView(this).apply {
                text = name
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.rgb(150, 25, 40))
            }
            val cartons = edit("تعداد کارتن", true)
            val weight = edit("وزن هر کارتن (کیلو)", true)
            val price = edit("قیمت هر کیلو (تومان)", true)
            val weightTotal = TextView(this)
            val total = TextView(this).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD }
            val recalc = {
                val c = cartons.number()
                val w = weight.number()
                val p = price.number()
                weightTotal.text = "وزن کل: ${fmt(c * w)} کیلوگرم"
                total.text = "جمع کل: ${fmt(c * w * p)} تومان"
            }
            listOf(cartons, weight, price).forEach { field ->
                field.setTextColor(Color.BLACK)
                field.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                field.isEnabled = true // all users may enter a new sale; saved records are editable only by owner
                field.addTextChangedListener(SimpleWatcher { recalc() })
                card.addView(field)
            }
            card.addView(weightTotal); card.addView(total)
            val save = Button(this).apply {
                text = "ذخیره فروش $name"
                setOnClickListener {
                    if (cartons.number() <= 0 || weight.number() <= 0 || price.number() <= 0) {
                        toast("تعداد کارتن، وزن و قیمت باید بیشتر از صفر باشند.")
                    } else {
                        saveSale(name, cartons.number(), weight.number(), price.number())
                    }
                }
            }
            card.addView(save)
            rows[name] = ProductInputs(cartons, weight, price, total, weightTotal)
            recalc()
            root.addView(card)
            val gap = TextView(this).apply { text = ""; height = 12 }
            root.addView(gap)
        }

        if (isOwner) {
            val review = Button(this).apply {
                text = "★ ثبت بررسی حساب تا امروز"
                setOnClickListener {
                    val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                    db.collection("settings").document("app")
                        .set(mapOf("reviewedThrough" to date, "reviewedBy" to auth.currentUser?.uid), SetOptions.merge())
                        .addOnSuccessListener {
                            reviewDate = date
                            statusText.text = "حساب بررسی شده تا: $reviewDate"
                            toast("تاریخ بررسی حساب ذخیره شد.")
                        }.addOnFailureListener { toast("ذخیره تاریخ بررسی ناموفق بود.") }
                }
            }
            root.addView(review)
        }
        val history = Button(this).apply {
            text = "گزارش فروش‌های ثبت‌شده"
            setOnClickListener { showHistory() }
        }
        root.addView(history)
        val logout = Button(this).apply {
            text = "خروج"
            setOnClickListener { auth.signOut(); showLogin() }
        }
        root.addView(logout)

        db.collection("settings").document("app").get().addOnSuccessListener { s ->
            reviewDate = s.getString("reviewedThrough") ?: ""
            statusText.text = if (reviewDate.isBlank()) "هنوز تاریخ بررسی حساب ثبت نشده است" else "حساب بررسی شده تا: $reviewDate"
        }
        setContentView(root)
    }

    private fun saveSale(name: String, cartons: Double, weight: Double, price: Double) {
        val user = auth.currentUser ?: return toast("ابتدا وارد شوید.")
        val saleDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val data = hashMapOf<String, Any>(
            "product" to name, "cartons" to cartons, "cartonWeightKg" to weight,
            "pricePerKg" to price, "totalWeightKg" to cartons * weight,
            "totalAmount" to cartons * weight * price, "saleDate" to saleDate,
            "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp(),
            "createdByUid" to user.uid, "createdByPhone" to (user.phoneNumber ?: ""),
            "createdByName" to (user.displayName ?: user.phoneNumber ?: "کاربر")
        )
        db.collection("sales").add(data)
            .addOnSuccessListener { toast("فروش «$name» ذخیره شد.") }
            .addOnFailureListener { toast("ثبت فروش ناموفق بود: ${it.localizedMessage}") }
    }

    private fun showHistory() {
        val oldRoot = root
        root = page()
        addTitle("گزارش فروش")
        val back = Button(this).apply { text = "بازگشت"; setOnClickListener { showSales() } }
        root.addView(back)
        db.collection("sales").orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(200).get().addOnSuccessListener { snapshot ->
                snapshot.documents.forEach { d ->
                    val line = TextView(this).apply {
                        val amount = d.getDouble("totalAmount") ?: 0.0
                        text = "${d.getString("saleDate") ?: "-"} | ${d.getString("product") ?: "-"} | ${fmt(d.getDouble("cartons") ?: 0.0)} کارتن | ${fmt(d.getDouble("totalWeightKg") ?: 0.0)} کیلو | ${fmt(amount)} تومان | ${d.getString("createdByPhone") ?: ""}"
                        textSize = 14f
                        setPadding(0, 10, 0, 10)
                    }
                    root.addView(line)
                    root.addView(TextView(this).apply { text = "────────────────────────" })
                }
            }.addOnFailureListener { toast("گزارش دریافت نشد.") }
        setContentView(root)
    }

    private fun page() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(24, 24, 24, 24)
        setBackgroundColor(Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(-1, -1)
    }

    private fun addTitle(s: String) {
        root.addView(TextView(this).apply {
            text = s; textSize = 24f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(150, 25, 40)); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        })
    }
    private fun addText(s: String) {
        root.addView(TextView(this).apply { text = s; textSize = 16f; setTextColor(Color.DKGRAY); setPadding(0, 6, 0, 10) })
    }
    private fun edit(hintText: String, numeric: Boolean = false) = EditText(this).apply {
        hint = hintText
        isSingleLine = true
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(12, 8, 12, 8)
    }
    private fun EditText.number(): Double = text.toString().trim().replace(",", ".").toDoubleOrNull() ?: 0.0
    private fun fmt(n: Double): String = String.format(Locale.US, "%,.2f", n).trimEnd('0').trimEnd('.')
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
